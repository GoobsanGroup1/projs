# quiz-project.

## Authors
- [Ahmed halista](https://github.com/halista11)
- Add your clickable username here. It should point to your GitHub account.

### description of quiz-Project
This program describes for quiz questions about javaScript and it contains multiple chiose questions and i made it from scratch  html , css ,bootstrap. ,javaScript and jquary and it also this program will help as you can do like this program or better if you need to use this program follow these instructions:

## Project setup instructions
To start using this project use the following commands:
- `git clone https://github.com/halista11/quiz-proj
- `cd quiz-project
- `atom .`



## License info

Copyright (c) 2021 goobsan school.
